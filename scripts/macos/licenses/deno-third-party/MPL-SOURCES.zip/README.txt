Unmodified crate source archives for Deno MPL dependencies. Extract with standard ZIP/tar tools. Each crate retains its license. See PROVENANCE.json for exact upstream hashes and URLs.
